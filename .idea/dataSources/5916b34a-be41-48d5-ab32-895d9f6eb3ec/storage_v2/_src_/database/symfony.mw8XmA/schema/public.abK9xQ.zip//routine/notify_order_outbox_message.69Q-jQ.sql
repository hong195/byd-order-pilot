create function notify_order_outbox_message() returns trigger
    language plpgsql
as
$$
    BEGIN
        PERFORM pg_notify('order_outbox_message', NEW.queue_name::text);
        RETURN NEW;
    END;
$$;

alter function notify_order_outbox_message() owner to symfony;

