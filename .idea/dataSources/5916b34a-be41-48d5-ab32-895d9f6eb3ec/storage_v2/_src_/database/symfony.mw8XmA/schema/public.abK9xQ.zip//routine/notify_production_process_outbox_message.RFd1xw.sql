create function notify_production_process_outbox_message() returns trigger
    language plpgsql
as
$$
    BEGIN
        PERFORM pg_notify('production_process_outbox_message', NEW.queue_name::text);
        RETURN NEW;
    END;
$$;

alter function notify_production_process_outbox_message() owner to symfony;

